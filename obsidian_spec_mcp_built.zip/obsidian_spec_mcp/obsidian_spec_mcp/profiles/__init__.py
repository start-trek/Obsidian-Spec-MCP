"""Bundled vault profiles."""
